package com.example.reconnaitre

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.FileProvider
import com.digi.xbee.api.android.XBeeBLEDevice
import com.digi.xbee.api.exceptions.BluetoothAuthenticationException
import com.digi.xbee.api.exceptions.XBeeException
import java.io.File
import java.io.FileOutputStream
import java.io.FileWriter
import java.io.IOException
import java.nio.charset.StandardCharsets

class MyActivity : AppCompatActivity() {
    private val REQUEST_BLUETOOTH_PERMISSIONS = 1
    private var myXBeeDevice: XBeeBLEDevice? = null
    private var textMessages: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val macAddressInput = findViewById<EditText>(R.id.edit_mac_address)
        val passwordInput = findViewById<EditText>(R.id.edit_password)
        val connectButton = findViewById<Button>(R.id.btn_connect)
        val checkConnectionButton = findViewById<Button>(R.id.btn_check_connection)
        val sendEmailButton = findViewById<Button>(R.id.btn_send_email)
        val resetFileButton = findViewById<Button>(R.id.btn_reset_file)
        textMessages = findViewById(R.id.text_messages)

        checkAndRequestPermissions()

        connectButton.setOnClickListener { v: View? ->
            val macAddress = macAddressInput.text.toString().trim { it <= ' ' }
            val password = passwordInput.text.toString().trim { it <= ' ' }

            if (macAddress.isEmpty()) {
                showToastMessage("Please enter a MAC address")
                return@setOnClickListener
            }
            connectToDevice(macAddress, if (password.isEmpty()) null else password)
        }

        checkConnectionButton.setOnClickListener { v: View? ->
            if (myXBeeDevice != null && myXBeeDevice!!.isOpen) {
                showToastMessage("Still connected")
            } else {
                showToastMessage("Not connected")
            }
        }

        sendEmailButton.setOnClickListener { v: View? -> sendEmailWithFile() }
        resetFileButton.setOnClickListener{resetFile()}
    }

    private fun resetFile(){
        val fileName = "received_messages.txt"
        val file = File(filesDir, fileName)
        try{
            val fileWriter = FileWriter(file,false)
            fileWriter.write("")
            fileWriter.close()
            runOnUiThread{Toast.makeText(this,"Fichier vide",Toast.LENGTH_SHORT).show()}
        }catch(e: IOException){
            runOnUiThread{Toast.makeText(this,"Error",Toast.LENGTH_SHORT).show()}
        }
    }

    private fun scrollToBottom(){
        val scrollView = findViewById<ScrollView>(R.id.scroll_view)
        scrollView.post{scrollView.fullScroll(View.FOCUS_DOWN)}
    }

    private fun connectToDevice(macAddress: String, password: String?) {
        Thread {
            try {
                Log.d("BLE", "Attempting to connect to $macAddress")
                myXBeeDevice = XBeeBLEDevice(this, macAddress, password)
                myXBeeDevice!!.open()
                showToastMessage("Device open: $macAddress")

                myXBeeDevice!!.addMicroPythonDataListener { data: ByteArray? ->
                    val receivedMessage =
                        String(data!!, StandardCharsets.UTF_8)
                    addMessage("Received: $receivedMessage")
                    scrollToBottom()
                    writeToFile(receivedMessage)
                }
            } catch (e: BluetoothAuthenticationException) {
                Log.e("BLE", "Authentication error: " + e.message)
                showToastMessage("Authentication error: " + e.message)
            } catch (e: XBeeException) {
                Log.e("BLE", "Could not open device: " + e.message)
                showToastMessage("Could not open device: " + e.message)
            }
        }.start()
    }

    @SuppressLint("SetTextI18n")
    private fun addMessage(message: String) {
        runOnUiThread {
            val currentText = textMessages!!.text.toString()
            textMessages!!.text = """
                $currentText
                $message
                """.trimIndent()
        }
    }

    private fun writeToFile(message: String) {
        val file = File(filesDir, "received_messages.txt")
        try {
            FileOutputStream(file, true).use { fos ->
                fos.write(
                    (message + "\n").toByteArray(
                        StandardCharsets.UTF_8
                    )
                )
            }
        } catch (e: IOException) {
            Log.e("FileIO", "Error writing to file: " + e.message)
        }
    }

    private fun sendEmailWithFile() {
        val file = File(filesDir, "received_messages.txt")
        if (!file.exists()) {
            showToastMessage("No file to send")
            return
        }
        val fileUri = FileProvider.getUriForFile(this, "com.example.reconnaitre.fileprovider", file)

        val intent = Intent(Intent.ACTION_SEND)
        intent.setType("text/plain")
        intent.putExtra(Intent.EXTRA_SUBJECT, "Received Messages Log")
        intent.putExtra(Intent.EXTRA_TEXT, "Please find the attached log file.")
        intent.putExtra(Intent.EXTRA_STREAM, fileUri)
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)

        if (intent.resolveActivity(packageManager) != null) {
            startActivity(Intent.createChooser(intent, "Send Email"))
        } else {
            showToastMessage("No email app found")
        }
    }

    private fun checkAndRequestPermissions() {
        val permissions = arrayOf(
            Manifest.permission.BLUETOOTH,
            Manifest.permission.BLUETOOTH_ADMIN,
            Manifest.permission.BLUETOOTH_CONNECT,
            Manifest.permission.BLUETOOTH_SCAN,
            Manifest.permission.ACCESS_FINE_LOCATION
        )
        ActivityCompat.requestPermissions(this, permissions, REQUEST_BLUETOOTH_PERMISSIONS)
    }

    private fun showToastMessage(message: String) {
        runOnUiThread {
            Toast.makeText(this@MyActivity, message, Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (myXBeeDevice != null) {
            myXBeeDevice!!.close()
        }
    }
}